<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class skill extends Model
{
protected $fillable=[
 'innovative_idea','software','application','cyber_security','database','web_application',
    ];
}
