<?php

namespace App\Http\Controllers;

use DB;
use Illuminate\Validation\Validator;
use App\massage;
use Redirect;
use Illuminate\Http\Request;

class massagecontroller extends Controller
{
	
  public function send_massage(Request $request){

  $validatedData = $request->validate([
           'name' => 'required|max:100',
           'email' => 'required|max:255',
           'subject' => 'required|max:255',
           'massage' => 'required|max:400',
       
       
    ]);
  	$data=array();
  	$data['name']=$request->name;
  	$data['email']=$request->email;
  	$data['subject']=$request->subject;
  	$data['massage']=$request->massage;
  	$all=DB::table('massages')->insert($data);
  	  if ($all) {
                 $notification=array(
                 'messege'=>'Successfully Massage Send To Adnan..!! As soon as possible i will replay your Massage !! Thank You.  ',
                 'alert-type'=>'success'
                  );
                return Redirect()->back()->with($notification);                      
             }else{
              $notification=array(
                 'messege'=>'error ',
                 'alert-type'=>'success'
                  );
                 return Redirect()->back()->with($notification);
             } 

  }
  
}
