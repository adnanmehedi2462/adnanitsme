<?php

namespace App\Http\Controllers;
use DB; 
use Illuminate\Validation\Validator;
use App\skill;
use App\massage;

use Redirect;
use Illuminate\Http\Request;


class skillcontroller extends Controller
{
     /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }
    /////////////////////////////////////////////////////////
    public function index(){
    	return view("add_expert");
    }
    public function insert_expert(Request $request){
         $validatedData = $request->validate([
           'innovative_idea' => 'required|max:255',
           'software' => 'required|max:255',
           'application' => 'required|max:255',
           'cyber_security' => 'required|max:255',
           'database' => 'required|max:255',
           'web_application' => 'required|max:255',
    ]);
         $data=array();
         $data['innovative_idea']=$request->innovative_idea;
         $data['software']=$request->software;
         $data['application']=$request->application;
         $data['cyber_security']=$request->cyber_security;
         $data['database']=$request->database;
         $data['web_application']=$request->web_application;
         $all=DB::table('skills')->insert($data);
         if ($all) {
                 $notification=array(
                 'messege'=>'Successfully data insert ',
                 'alert-type'=>'success'
                  );
                return Redirect()->route('add_expert')->with($notification);                      
             }else{
              $notification=array(
                 'messege'=>'error ',
                 'alert-type'=>'error'
                  );
                 return Redirect()->back()->with($notification);
             } 



       }
       public function all_expert(){
      $experts=DB::table('skills')->get();
        return view("all_skill",compact('experts'));
       }

       public function delete_expert($id){
        $id=\Crypt::decrypt($id);
        $delete=skill::findorfail($id)->delete();
       
          if ($delete) {
                 $notification=array(
                 'messege'=>'Successfully experts Delete ',
                 'alert-type'=>'success'
                  );
                return Redirect()->route('all_expert')->with($notification);                      
             }else{
              $notification=array(
                 'messege'=>'error ',
                 'alert-type'=>'da'
                  );
                 return Redirect()->back()->with($notification);
             } 

       }
       public function edit_expert($id){
          $id=\Crypt::decrypt($id);
          $edit_experts=skill::findorfail($id);
      return view("edit_expert",compact('edit_experts'));
       }
       public function update_expert(Request $request,$id){
            $data=array();
         $data['innovative_idea']=$request->innovative_idea;
         $data['software']=$request->software;
         $data['application']=$request->application;
         $data['cyber_security']=$request->cyber_security;
         $data['database']=$request->database;
         $data['web_application']=$request->web_application;
         $all=DB::table('skills')->where('id',$id)->update($data);
         if ($all) {
                 $notification=array(
                 'messege'=>'Successfully data Update ',
                 'alert-type'=>'success'
                  );
                return Redirect()->route('all_expert')->with($notification);                      
             }else{
              $notification=array(
                 'messege'=>'Something Happend Wrong ',
                 'alert-type'=>'error'
                  );
                 return Redirect()->back()->with($notification);
             } 

       }
public function all_massage(){
  $massages=massage::all();
  return view("all_massage",compact('massages'));
}
public function delete_massage($id){
  $id=\Crypt::decrypt($id);
  $delete=massage::findorfail($id)->delete();
   if ($delete) {
                 $notification=array(
                 'messege'=>'Successfully Delete massage ',
                 'alert-type'=>'success'
                  );
                return Redirect()->route('all_massage')->with($notification);                      
             }else{
              $notification=array(
                 'messege'=>'Something Happend Wrong ',
                 'alert-type'=>'error'
                  );
                 return Redirect()->back()->with($notification);
             } 



}


    
}
