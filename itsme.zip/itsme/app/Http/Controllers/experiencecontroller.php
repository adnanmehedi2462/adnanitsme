<?php

namespace App\Http\Controllers;
use DB;
use Illuminate\Validation\Validator;
use App\experience;
use Redirect;
use Illuminate\Http\Request;

class experiencecontroller extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }
    //start /////////////////////////////////////////////
    public function index(){
    	return view("add_experience");
    }
    public function insert_exp(Request $request){
    	 $validatedData = $request->validate([
           'full_developer' => 'required|max:500',
           'front_end' => 'required|max:500',
           'laravel' => 'required|max:500',
           'web_application' => 'required|max:500',
       
       
    ]);
  	$data=array();
  	$data['full_developer']=$request->full_developer;
  	$data['front_end']=$request->front_end;
  	$data['laravel']=$request->laravel;
  	$data['web_application']=$request->web_application;
  	$all=DB::table('experiences')->insert($data);
  	if ($all) {
                 $notification=array(
                 'messege'=>'Experience Add Successfully!!',
                 'alert-type'=>'success'
                  );
                return Redirect()->route("add_exp")->with($notification);                      
             }else{
              $notification=array(
                 'messege'=>'error ',
                 'alert-type'=>'error'
                  );
              return Redirect()->back()->with($notification);
              }   
              

        }

public function all_exp(){
$all_exp=experience::all();
return view("all_experience",compact('all_exp'));
}
public function edit_exp($id){
	  $id=\Crypt::decrypt($id);
        $edit_exps=experience::findorfail($id);
	return view("edit_experience",compact('edit_exps'));

}
public function update_exp(Request $request,$id){
$data=array();
    $data['full_developer']=$request->full_developer;
    $data['front_end']=$request->front_end;
    $data['laravel']=$request->laravel;
    $data['web_application']=$request->web_application;
    $alls=DB::table('experiences')->where('id',$id)->update($data);
    if ($alls) {
                 $notification=array(
                 'messege'=>'Experience Update Successfully!!',
                 'alert-type'=>'success'
                  );
                return Redirect()->route("all_exp")->with($notification);                      
             }else{
              $notification=array(
                 'messege'=>'error ',
                 'alert-type'=>'error'
                  );
              return Redirect()->back()->with($notification);
              }

}
public function delete_exp($id){
$id=\Crypt::decrypt($id);
  $delete=experience::findorfail($id)->delete();
   if ($delete) {
                 $notification=array(
                 'messege'=>'Successfully Delete ',
                 'alert-type'=>'success'
                  );
                return Redirect()->route('all_exp')->with($notification);                      
             }else{
              $notification=array(
                 'messege'=>'Something Happend Wrong ',
                 'alert-type'=>'error'
                  );
                 return Redirect()->back()->with($notification);
             } 

}

}
