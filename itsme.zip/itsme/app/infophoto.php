<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class infophoto extends Model
{
   protected $fillable=[
 'name','photo'
    ];
}
