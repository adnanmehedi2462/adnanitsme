<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class experience extends Model
{
    protected $fillable=[
 'full_developer','front_end','laravel','web_application',
    ];
}
