$(document).ready(function() {
  // Start mixitup
  $('#portfolio').mixItUp();
});
