@extends('layouts.app')
@section('content')
<div class="content-page">
                <!-- Start content -->
                <div class="content">
                    <div class="container">

                        <!-- Page-Title -->
                        <div class="row">
                            <div class="col-sm-12">
                                <h4 class="pull-left page-title">Welcome !</h4>
                                <ol class="breadcrumb pull-right">
                                    <li><a href="{{route('backend')}}">Adnan</a></li>
                                    <li class="active">Dashboard</li>
                                </ol>
                            </div>
                        </div>

        <!-- Start Widget -->
        <div class="row">
    <!-- Basic example --><div class="col-md-2"></div>
                            <div class="col-md-8">
                                <div class="panel panel-default">
                                    <div class="panel-heading"><h3 class="panel-title"> Add Expertice</h3></div>
                                                                          
                                      @if ($errors->any())
                                          <div class="alert alert-danger">
                                              <ul>
                                                  @foreach ($errors->all() as $error)
                                                      <li>{{ $error }}</li>
                                                  @endforeach
                                              </ul>
                                          </div>
                                      @endif


                                    <div class="panel-body">
                                        <form role="form" action="{{url('/update_expert/'.$edit_experts->id)}}" method="post" enctype="multipart/form-data">
                                          @csrf

                                     
                                     <label for="exampleInputPassword11">INNOVATIVE IDEAS</label>
                                         <textarea class="form-control" cols="50" rows="3" name="innovative_idea">{{$edit_experts->innovative_idea}}</textarea>
                                          <div class="form-group">
                                         <label for="exampleInputPassword11">SOFTWARE</label>
                                         <textarea class="form-control" cols="50" rows="3" name="software">{{$edit_experts->software}}</textarea>
                                      </div>
                                      <div class="form-group">
                                         <label for="exampleInputPassword11">APPLICATION
                                         </label>
                                         <textarea class="form-control" cols="50" rows="3" name="application">{{$edit_experts->application}}</textarea>
                                      </div>
                                      <div class="form-group">
                                         <label for="exampleInputPassword11">CYBER SECURITY</label>
                                         <textarea class="form-control" cols="50" rows="3" name="cyber_security">{{$edit_experts->cyber_security}}</textarea>
                                      </div> 
                                      <div class="form-group">
                                         <label for="exampleInputPassword11">DATABASE</label>
                                         <textarea class="form-control" cols="50" rows="3" name="database">{{$edit_experts->database}}</textarea>
                                      </div>
                                      <div class="form-group">
                                         <label for="exampleInputPassword11">WEB APPLICATION</label>
                                         <textarea class="form-control" cols="50" rows="3" name="web_application">{{$edit_experts->web_application}}</textarea>
                                      </div>
                                   
                                          

                                       <button type="submit" class="btn btn-purple waves-effect waves-light">Update</button>
                                        </form>
                                         </div>
                                    </div><!-- panel-body -->
                                </div> <!-- panel -->
                            </div> <!-- col-->
                          </div> 
                          <!-- End row-->

                    </div> <!-- end row -->

               </div> <!-- container -->
                                 
      </div> <!-- content -->

@endsection








