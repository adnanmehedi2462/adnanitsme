@extends('layouts.app')
@section('content')
<div class="content-page">
                <!-- Start content -->
                <div class="content">
                    <div class="container">

                        <!-- Page-Title -->
                        <div class="row">
                            <div class="col-sm-12">
                                <h4 class="pull-left page-title">Welcome !</h4>
                                <ol class="breadcrumb pull-right">
                                    <li><a href="{{route('backend')}}">Adnan</a></li>
                                    <li class="active">Dashboard</li>
                                </ol>
                            </div>
                        </div>

        <!-- Start Widget -->
        <div class="row">
    <!-- Basic example --><div class="col-md-2"></div>
                            <div class="col-md-8">
                                <div class="panel panel-default">
                                    <div class="panel-heading"><h3 class="panel-title"> Add Experience</h3></div>
                                                                          
                                      @if ($errors->any())
                                          <div class="alert alert-danger">
                                              <ul>
                                                  @foreach ($errors->all() as $error)
                                                      <li>{{ $error }}</li>
                                                  @endforeach
                                              </ul>
                                          </div>
                                      @endif


                                    <div class="panel-body">
                                        <form role="form" action="{{url('/insert_exp')}}" method="post">
                                          @csrf

                                     
                                     <label for="exampleInputPassword11">Full Stack Developer</label>
                                         <textarea class="form-control" cols="50" rows="3" name="full_developer"></textarea>
                                          <div class="form-group">
                                         <label for="exampleInputPassword11">Front End Developer</label>
                                         <textarea class="form-control" cols="50" rows="3" name="front_end"></textarea>
                                      </div>
                                      <div class="form-group">
                                         <label for="exampleInputPassword11">Laravel Fermwork
                                         </label>
                                         <textarea class="form-control" cols="50" rows="3" name="laravel"></textarea>
                                      </div>
                                      <div class="form-group">
                                         <label for="exampleInputPassword11">Web Application Development</label>
                                         <textarea class="form-control" cols="50" rows="3" name="web_application"></textarea>
                                      </div> 
                                      
                                   
                                          

                                       <button type="submit" class="btn btn-purple waves-effect waves-light">Submit</button>
                                        </form>
                                         </div>
                                    </div><!-- panel-body -->
                                </div> <!-- panel -->
                            </div> <!-- col-->
                          </div> 
                          <!-- End row-->

                    </div> <!-- end row -->

               </div> <!-- container -->
                                 
      </div> <!-- content -->

@endsection