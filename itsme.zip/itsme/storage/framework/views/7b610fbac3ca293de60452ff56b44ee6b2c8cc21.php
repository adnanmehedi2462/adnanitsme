<!DOCTYPE HTML>
<html>
    <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Adnan's cyber station</title>
    <link rel="icon" type="image/png" href="https://i.ibb.co/0rSzthv/hacker-PNG33.png"/>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="this is adnan's protfolio web site ." />
    <meta name="keywords" content="adnancyberway, adnan cyber way, adnan cyber, adnan protfolio site, adnan" />
    <meta name="author" content="Al-Adnan Mahdi" />

  <!-- Facebook and Twitter integration -->
    <!--<meta property="og:title" content=""/>-->
    <!--<meta property="og:image" content=""/>-->
    <!--<meta property="og:url" content=""/>-->
    <!--<meta property="og:site_name" content=""/>-->
    <!--<meta property="og:description" content=""/>-->
    <!--<meta name="twitter:title" content="" />-->
    <!--<meta name="twitter:image" content="" />-->
    <!--<meta name="twitter:url" content="" />-->
    <!--<meta name="twitter:card" content="" />-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" async>

    <!-- Place favicon.ico and apple-touch-icon.png in the root directory -->
    <link rel="shortcut icon" href="<?php echo e(asset('public/favicon.ico')); ?>">
     <link href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.0.1/css/toastr.css" rel="stylesheet" >
    <link href="https://fonts.googleapis.com/css?family=Quicksand:300,400,500,700" rel="stylesheet" async>
    <link href="https://fonts.googleapis.com/css?family=Playfair+Display:400,400i,700" rel="stylesheet" async>
    
    <!-- Animate.css -->
    <link rel="stylesheet" href="<?php echo e(asset('public/home/css/animate.css')); ?>">
    <!-- Icomoon Icon Fonts-->
    <link rel="stylesheet" href="<?php echo e(asset('public/home/css/icomoon.css')); ?>">
    <!-- Bootstrap  -->
    <link rel="stylesheet" href="<?php echo e(asset('public/home/css/bootstrap.css')); ?>">
    <!-- Flexslider  -->
    <link rel="stylesheet" href="<?php echo e(asset('public/home/css/flexslider.css')); ?>">
    <!-- Flaticons  -->
    <link rel="stylesheet" href="<?php echo e(asset('public/home/fonts/flaticon/font/flaticon.css')); ?>">
    <!-- Owl Carousel -->
    <link rel="stylesheet" href="<?php echo e(asset('public/home/css/owl.carousel.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('public/home/css/owl.theme.default.min.css')); ?>">
    <!-- Theme style  -->
    <link rel="stylesheet" href="<?php echo e(asset('public/home/css/style.css')); ?>">

    <!-- Modernizr JS -->
    <script src="<?php echo e(asset('public/home/js/modernizr-2.6.2.min.js')); ?>" async></script>




    <!-- protfollio -->
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js" async></script>
    <script src="https://cdn.jsdelivr.net/jquery.mixitup/latest/jquery.mixitup.min.js" async></script>
    <script src="https://mixitup.kunkalabs.com/wp-content/themes/mixitup.kunkalabs/js/main.min.js?ver=1.3.1" async></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.97.5/js/materialize.min.js" async></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/typed.js/1.1.1/typed.min.js" async></script>

  
        <style>
  body {

   cursor: url(<?php echo e(url('public/cur/ab.cur')); ?>), auto;
}
.colorlib-services{

   cursor: url(<?php echo e(url('public/cur/ch.cur')); ?>), auto;
}
.colorlib-skills{

   cursor: url(<?php echo e(url('public/cur/cd.cur')); ?>), auto;
}

.colorlib-experience{

   cursor: url(<?php echo e(url('public/cur/k.cur')); ?>), auto;
}
a{

   cursor: url(<?php echo e(url('public/cur/co.cur')); ?>), auto;
}

.panel-heading a.collapsed {
    background: /* Permalink - use to edit and share this gradient: https://colorzilla.com/gradient-editor/#efc5ca+0,ed959f+12,efc5ca+27,ea838d+40,efc5ca+56,ba2737+71,efc5ca+85,ef5665+100 */
background: rgb(239,197,202); /* Old browsers */
background: -moz-linear-gradient(-45deg,  rgba(239,197,202,1) 0%, rgba(237,149,159,1) 12%, rgba(239,197,202,1) 27%, rgba(234,131,141,1) 40%, rgba(239,197,202,1) 56%, rgba(186,39,55,1) 71%, rgba(239,197,202,1) 85%, rgba(239,86,101,1) 100%); /* FF3.6-15 */
background: -webkit-linear-gradient(-45deg,  rgba(239,197,202,1) 0%,rgba(237,149,159,1) 12%,rgba(239,197,202,1) 27%,rgba(234,131,141,1) 40%,rgba(239,197,202,1) 56%,rgba(186,39,55,1) 71%,rgba(239,197,202,1) 85%,rgba(239,86,101,1) 100%); /* Chrome10-25,Safari5.1-6 */
background: linear-gradient(135deg,  rgba(239,197,202,1) 0%,rgba(237,149,159,1) 12%,rgba(239,197,202,1) 27%,rgba(234,131,141,1) 40%,rgba(239,197,202,1) 56%,rgba(186,39,55,1) 71%,rgba(239,197,202,1) 85%,rgba(239,86,101,1) 100%); /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#efc5ca', endColorstr='#ef5665',GradientType=1 ); /* IE6-9 fallback on horizontal gradient */

    border: 1px solid #f3eeee !important;
    color: #fff;
}
.panel-heading a.collapsed:after {
    display: none;
}
.panel-heading a:after {
   display: none;
}
    </style>


    </head>
    <body>
        <!-- Load Facebook SDK for JavaScript -->
      <div id="fb-root"></div>
      <script>
        window.fbAsyncInit = function() {
          FB.init({
            xfbml            : true,
            version          : 'v6.0'
          });
        };

        (function(d, s, id) {
        var js, fjs = d.getElementsByTagName(s)[0];
        if (d.getElementById(id)) return;
        js = d.createElement(s); js.id = id;
        js.src = 'https://connect.facebook.net/en_US/sdk/xfbml.customerchat.js';
        fjs.parentNode.insertBefore(js, fjs);
      }(document, 'script', 'facebook-jssdk'));</script>

      <!-- Your customer chat code -->
      <div class="fb-customerchat"
        attribution=setup_tool
        page_id="110411093965168"
  theme_color="#fa3c4c"
  logged_in_greeting="Hi! Im Adnan How can i help you?"
  logged_out_greeting="Hi! Im Adnan How can i help you?">
      </div>
    <div id="colorlib-page">
        <div class="container-wrap">
        <a href="#" class="js-colorlib-nav-toggle colorlib-nav-toggle" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar"><i></i></a>
                            <aside id="colorlib-aside" role="complementary" class="border js-fullheight" style="background-color:/* Permalink - use to edit and share this gradient: https://colorzilla.com/gradient-editor/#e5c599+0,e5c599+10,e9d4b3+62,c19e67+75 */
              background: rgb(229,197,153); /* Old browsers */
           background: -moz-radial-gradient(center, ellipse cover,  rgba(229,197,153,1) 0%, rgba(229,    197,153,1) 10%, rgba(233,212,179,1) 62%, rgba(193,158,103,1) 75%); /* FF3.6-15 */
            background: -webkit-radial-gradient(center, ellipse cover,  rgba(229,197,153,1) 0%,rgba(229,197,153,1) 10%,rgba(233,212,179,1) 62%,rgba(193,158,103,1) 75%); /* Chrome10-25,Safari5.1-6 */
              background: radial-gradient(ellipse at center,  rgba(229,197,153,1) 0%,rgba(229,197,153,1) 10%,rgba(233,212,179,1) 62%,rgba(193,158,103,1) 75%); /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
            filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#e5c599', endColorstr='      #c19e67',GradientType=1 ); /* IE6-9 fallback on horizontal gradient */

                ">
                            <div class="text-center">
                <div class="colorlib-footer" style="margin-top: -30px;padding-bottom: 15px;">
        
                <ul>
                    <li><a href="https://www.facebook.com/adnan.xohan.1" target="_blank" style="color: #3b5999; "><i class="fa fa-facebook"></i></a></li>
                    <li><a href="https://twitter.com/adnanjohan9" target="_blank" style="color: #55acee;"><i class="fa fa-twitter"></i></a></li>
                    <li><a href="https://www.instagram.com/adnan.xohan/" target="_blank" style="color:#e4405f;"><i class="fa fa-instagram"></i></a></li>
                    <li><a href="https://www.linkedin.com/in/al-adnan-mehedi-7814711a7/" target="_blank" style="color: #0077B5;"><i class="fa fa-linkedin"></i></a></li>
                </ul>
            </div>
    <?php

    $edit_info = DB::table('infophotos')->orderBy('id', 'desc')
    ->limit(1)
    ->get();

     ?>
     <?php $__currentLoopData = $edit_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $edit_infos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <div class="author-img" style="background-image:url(<?php echo e(url($edit_infos->photo)); ?>)
                 "> </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <h1 id="colorlib-logo"><a href="index.html">Adnan Mahdi</a></h1>
                <span class="position"><div class="type-wrap" style="margin-top: -30px;t"><!-- add static words/sentences here (i.e. text that you don't want to be removed)-->
                  <span id="typed" style="white-space:pre; font-size: 17px; background-color: black;color: #fff;padding: 10px;" class="typed">
                  </span>
                </div></span>
            </div>
            

                <script type="text/javascript">  
    $("#typed").typed({
        strings: ["Im web Designer .", "Web Developer", "  Application Developer.","  cyber analyst."],
        typeSpeed: 100,
        startDelay: 0,
        backSpeed: 60,
        backDelay: 2000,
        loop: true,
        cursorChar: "|",
        contentType: 'html'
    });</script>
            <nav id="colorlib-main-menu" role="navigation" class="navbar">

         



                <div id="navbar" class="collapse">
                    <ul>
                        <li class="active"><a href="#" data-nav-section="home">Home</a></li>
                        <li><a href="#" data-nav-section="about">About</a></li>
                        <li><a href="#" data-nav-section="services">Services</a></li>
                        <li><a href="#" data-nav-section="skills">Skills</a></li>
                        <li><a href="#" data-nav-section="education">Education</a></li>
                        <li><a href="#" data-nav-section="experience">Experience</a></li>
                        <li><a href="#" data-nav-section="work">Work</a></li>
                        <li><a href="#" data-nav-section="blog">Blog</a></li>
                        <li><a href="#" data-nav-section="contact">Contact</a></li>
                    </ul>
                    <div class="adnansr" style="text-align: center;">&copy;<span> Copyright 2020 (Adnan Mahdi)- All Right Reserved</span></div>

                </div>
            </nav>

        </aside>
        <?php
        $slids=DB::table("sliders")->orderBy('id', 'desc')
    ->limit(1)
    ->get();
        ?>
         <?php
    $cvss=DB::table("cvs")->orderBy('id', 'desc')
    ->limit(1)
    ->get();
        ?>

                             
        <div id="colorlib-main">
                                   <?php if($errors->any()): ?>
                                          <div class="alert alert-danger">
                                              <ul>
                                                  <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                      <li><?php echo e($error); ?> please go to below and send again!!! Thank you.</li>
                                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                              </ul>
                                          </div>
                                      <?php endif; ?>
            <section id="colorlib-hero" class="js-fullheight" data-section="home">
                <div class="flexslider js-fullheight">
                    <ul class="slides">
                        <?php $__currentLoopData = $slids; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li style="background-image:url(<?php echo e(url($row->photo)); ?>); background-position: center center; position: relative;" class="lazyloaded">
                        <div class="overlay"></div>
                        <div class="container-fluid">
                            <div class="row">
                                <div class="col-md-6 col-md-offset-3 col-md-pull-3 col-sm-12 col-xs-12 js-fullheight slider-text">
                                    <div class="slider-text-inner js-fullheight">
                                        <div class="desc1" style="background-image:url('https://drive.google.com/uc?id=1Jih0yZcpHbMScCVoZ703Cla7bRTzWCjk') ;background-position: left;" class="lazyloaded">
                                            <h1>Hi!  <br><?php echo e($row->about); ?></h1>
                                            <h2><?php echo e($row->about_two); ?></h2>
                                            <?php $__currentLoopData = $cvss; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rows): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <p><a href="<?php echo e(url($rows->cv)); ?>" class="btn btn-primary btn-learn"><?php echo e($rows->title); ?><i class="fa fa-download" class="lazyloaded"></i></a></p>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            </div>


                                    </div>

                                </div>
                                
                            </div>

                        </div>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php
                    $second_slids=DB::table("second_sliders")->orderBy('id', 'desc')
                    ->limit(1)
                    ->get();
                    ?>



                   <?php $__currentLoopData = $second_slids; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rows): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li style="background-image: url(<?php echo e(url($rows->photo)); ?>);background-position: center center; position: relative;" class="lazyloaded" >
                        <div class="overlay"></div>
                        <div class="container-fluid">
                            <div class="row">
                                <div class="col-md-6 col-md-offset-3 col-md-pull-3 col-sm-12 col-xs-12 js-fullheight slider-text">
                                    <div class="slider-text-inner">
                                        <div class="desc2" style="background-image: url(<?php echo e(URL::asset('https://drive.google.com/uc?id=1Jih0yZcpHbMScCVoZ703Cla7bRTzWCjk')); ?>);background-position: left;" class="lazyloaded"  >
                                            <h1>I am <br><?php echo e($rows->about); ?></h1>
                                                </h2>
                                                     <?php $__currentLoopData = $cvss; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rows): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <p><a  href="<?php echo e(url($rows->cv)); ?>"
                                                 class="btn btn-primary btn-learn" class="lazyloaded"><?php echo e($rows->title); ?><i class="fa fa-download"></i></a></p>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </section>


            <section class="colorlib-about" data-section="about">
                <div class="colorlib-narrow-content">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="row row-bottom-padded-sm animate-box" data-animate-effect="fadeInLeft">
                                <div class="col-md-12">
                                    <div class="about-desc">
                                        <span class="heading-meta">About Us</span>
                                        <h2 class="colorlib-heading">Who Am I?</h2>
                                        <p><strong>Hi I'm Adnan Mahdi</strong> .Im a web and application developer.I'm a freelancer. I have been working as a Web and Application Developer over the last 4 years. I used to work on fiverr .</p>
                                        <p> Moreover,Sometimes I work for different companies,as a Web and Application developer.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-3 animate-box" data-animate-effect="fadeInLeft">
                                    <div class="services color-1">
                                        <span class="icon2"><i class="fa fa-shield"></i></span>
                                        <h3>Cyber Security</h3>
                                    </div>
                                </div>
                                <div class="col-md-3 animate-box" data-animate-effect="fadeInRight">
                                    <div class="services color-2">
                                        <span class="icon2"><i class="fa fa-code"></i></span>
                                        <h3>Web Design&Dev. </h3>
                                    </div>
                                </div>
                                <div class="col-md-3 animate-box" data-animate-effect="fadeInTop">
                                    <div class="services color-3">
                                        <span class="icon2"><i class="fa fa-desktop"></i></span>
                                        <h3>Software</h3>
                                    </div>
                                </div>
                                <div class="col-md-3 animate-box" data-animate-effect="fadeInBottom">
                                    <div class="services color-4">
                                        <span class="icon2"><i class="fa fa-mobile"></i></span>
                                        <h3>Web Application</h3>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12 animate-box" data-animate-effect="fadeInLeft">
                                    <div class="hire" style="background-color: /* Permalink - use to edit and share this gradient: https://colorzilla.com/gradient-editor/#d24b5a+34,d24b5a+34,d24b5a+35,d24b5a+35,d24b5a+35,cc8c96+53,d24b5a+74,ba2737+74,efc5ca+86,f18e99+100 */
background: rgb(210,75,90); /* Old browsers */
background: -moz-linear-gradient(-45deg,  rgba(210,75,90,1) 34%, rgba(210,75,90,1) 34%, rgba(210,75,90,1) 35%, rgba(210,75,90,1) 35%, rgba(210,75,90,1) 35%, rgba(204,140,150,1) 53%, rgba(210,75,90,1) 74%, rgba(186,39,55,1) 74%, rgba(239,197,202,1) 86%, rgba(241,142,153,1) 100%); /* FF3.6-15 */
background: -webkit-linear-gradient(-45deg,  rgba(210,75,90,1) 34%,rgba(210,75,90,1) 34%,rgba(210,75,90,1) 35%,rgba(210,75,90,1) 35%,rgba(210,75,90,1) 35%,rgba(204,140,150,1) 53%,rgba(210,75,90,1) 74%,rgba(186,39,55,1) 74%,rgba(239,197,202,1) 86%,rgba(241,142,153,1) 100%); /* Chrome10-25,Safari5.1-6 */
background: linear-gradient(135deg,  rgba(210,75,90,1) 34%,rgba(210,75,90,1) 34%,rgba(210,75,90,1) 35%,rgba(210,75,90,1) 35%,rgba(210,75,90,1) 35%,rgba(204,140,150,1) 53%,rgba(210,75,90,1) 74%,rgba(186,39,55,1) 74%,rgba(239,197,202,1) 86%,rgba(241,142,153,1) 100%); /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#d24b5a', endColorstr='#f18e99',GradientType=1 ); /* IE6-9 fallback on horizontal gradient */

">
                                        <h2 style="color: #fff;">I am happy to know you <br>that 250+ projects done sucessfully!</h2>
                                        <a href="#con"class="btn-hire" style="color: #fff;border-color: #fff;">Hire me</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <?php
            $exp=DB::table('skills')->orderBy('id', 'desc')
            ->limit(1)
            ->get();
            ?>


            
            <section class="colorlib-services" data-section="services">
                <div class="colorlib-narrow-content">
                    <div class="row">
                        <div class="col-md-6 col-md-offset-3 col-md-pull-3 animate-box" data-animate-effect="fadeInLeft">
                            <span class="heading-meta">What I do?</span>
                            <h2 class="colorlib-heading">Here are some of my expertise</h2>
                        </div>
                    </div>
                    <?php $__currentLoopData = $exp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="row row-pt-md">
                        <div class="col-md-4 text-center animate-box">
                            <div class="services color-1">
                                <span class="icon">
                                    <i class="fa fa-lightbulb-o"></i>
                                </span>
                                <div class="desc">
                                    <h3>Innovative Ideas</h3>
                                    <p><?php echo e($row->innovative_idea); ?><!-- Innovation ideas are very important in programming and I am very aware of this --></p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 text-center animate-box">
                            <div class="services color-2">
                                <span class="icon">
                                    <i class="fa fa-desktop"></i>
                                </span>
                                <div class="desc">
                                    <h3>Software</h3>
                                    <p> <?php echo e($row->software); ?><!-- I always try to create new software. --></p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 text-center animate-box">
                            <div class="services color-3">
                                <span class="icon">
                                    <i class="fa fa-code"></i>
                                </span>
                                <div class="desc">
                                    <h3>Application</h3>
                                    <p><?php echo e($row->application); ?><!-- I created some mobile apps using Dart Programming Language --></p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 text-center animate-box">
                            <div class="services color-4">
                                <span class="icon">
                                    <i class="fa fa-shield"></i>
                                </span>
                                <div class="desc">
                                    <h3>CYBER SECURITY</h3>
                                    <p> <?php echo e($row->cyber_security); ?><!-- I do most of the graphic,s project using Illustrator..So i try to use it well.. --></p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 text-center animate-box">
                            <div class="services color-5">
                                <span class="icon">
                                    <i class="fa fa-database"></i>
                                </span>
                                <div class="desc">
                                    <h3>Database</h3>
                                    <p><?php echo e($row->database); ?><!-- Database is very importent for all the projects at Development level.So i try to use it well. --> </p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 text-center animate-box">
                            <div class="services color-6">
                                <span class="icon">
                                    <i class="fa fa-globe"></i>
                                </span>
                                <div class="desc">
                                    <h3>Web Application</h3>
                                    <p><?php echo e($row->web_application); ?><!-- In some cases web applications are very importent, such a (P.O.S) system.. --></p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </section>
            
            <div id="colorlib-counter" class="colorlib-counters" style="background-image: url('https://drive.google.com/uc?id=1ORjDaUuau_Kj56qKckLMgq61hDkOyaxJ'); background-position: center center;" data-stellar-background-ratio="0.5">
                <div class="overlay"></div>
                <div class="colorlib-narrow-content">
                    <div class="row">
                    </div>
                    <div class="row">
                    <!--    <div class="col-md-3 text-center animate-box">
                            <span class="colorlib-counter js-counter" data-from="0" data-to="309" data-speed="5000" data-refresh-interval="50"></span>
                            <span class="colorlib-counter-label">Cups of coffee</span>
                        </div> -->
                        <div class="col-md-4 text-center animate-box">
                            <span class="colorlib-counter js-counter" data-from="0" data-to="276" data-speed="5000" data-refresh-interval="50"></span>
                            <span class="colorlib-counter-label">Projects</span>
                        </div>
                        <div class="col-md-4 text-center animate-box">
                            <span class="colorlib-counter js-counter" data-from="0" data-to="34" data-speed="5000" data-refresh-interval="50"></span>
                            <span class="colorlib-counter-label">Clients</span>
                        </div>
                        <div class="col-md-4 text-center animate-box">
                            <span class="colorlib-counter js-counter" data-from="0" data-to="6" data-speed="5000" data-refresh-interval="50"></span>
                            <span class="colorlib-counter-label">Partners</span>
                        </div>
                    </div>
                </div>
            </div>

            <section class="colorlib-skills" data-section="skills">
                <div class="colorlib-narrow-content">
                    <div class="row">
                        <div class="col-md-6 col-md-offset-3 col-md-pull-3 animate-box" data-animate-effect="fadeInLeft">
                            <span class="heading-meta">My Specialty</span>
                            <h2 class="colorlib-heading animate-box">My Skills</h2>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12 animate-box" data-animate-effect="fadeInLeft">
                            <p>Here are all My skills........</p>
                        </div>
                        <div class="col-md-6 animate-box" data-animate-effect="fadeInLeft">
                            <div class="progress-wrap">
                                <h3>Photoshop</h3>
                                <div class="progress">
                                    <div class="progress-bar color-1" role="progressbar" aria-valuenow="75"
                                    aria-valuemin="0" aria-valuemax="100" style="width:75%">
                                    <span>75%</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 animate-box" data-animate-effect="fadeInRight">
                            <div class="progress-wrap">
                                <h3>jQuery& Vuejs</h3>
                                <div class="progress">
                                    <div class="progress-bar color-2" role="progressbar" aria-valuenow="60"
                                    aria-valuemin="0" aria-valuemax="100" style="width:60%">
                                    <span>60%</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 animate-box" data-animate-effect="fadeInLeft">
                            <div class="progress-wrap">
                                <h3>HTML5</h3>
                                <div class="progress">
                                    <div class="progress-bar color-3" role="progressbar" aria-valuenow="95"
                                    aria-valuemin="0" aria-valuemax="100" style="width:95%">
                                    <span>95%</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 animate-box" data-animate-effect="fadeInRight">
                            <div class="progress-wrap">
                                <h3>CSS3</h3>
                                <div class="progress">
                                    <div class="progress-bar color-4" role="progressbar" aria-valuenow="90"
                                    aria-valuemin="0" aria-valuemax="100" style="width:90%">
                                    <span>90%</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 animate-box" data-animate-effect="fadeInLeft">
                            <div class="progress-wrap">
                                <h3>PHP</h3>
                                <div class="progress">
                                    <div class="progress-bar color-5" role="progressbar" aria-valuenow="70"
                                    aria-valuemin="0" aria-valuemax="100" style="width:70%">
                                    <span>70%</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 animate-box" data-animate-effect="fadeInRight">
                            <div class="progress-wrap">
                                <h3>LARAVEL</h3>
                                <div class="progress">
                                    <div class="progress-bar color-6" role="progressbar" aria-valuenow="80"
                                    aria-valuemin="0" aria-valuemax="100" style="width:80%">
                                    <span>80%</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <section class="colorlib-education" data-section="education">
                <div class="colorlib-narrow-content">
                    <div class="row">
                        <div class="col-md-6 col-md-offset-3 col-md-pull-3 animate-box" data-animate-effect="fadeInLeft">
                            <span class="heading-meta">Education</span>
                            <h2 class="colorlib-heading animate-box">Education</h2>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12 animate-box" data-animate-effect="fadeInLeft">
                            <div class="fancy-collapse-panel">
                                <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
                                    
                                    <div class="panel panel-default">
                                        <div class="panel-heading" role="tab" id="headingTwo">
                                            <h4 class="panel-title" style="">
                                                <a class="collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">Bachelor Degree of Computer Science
                                                    <span class="pull-right"><i class="fa fa-plus-circle"></i></span>
                                                </a>
                                            </h4>
                                        </div>
                                        <div id="collapseTwo" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo">
                                            <div class="panel-body">
                                               <span class="heading-meta" style="font-size: 13px;">WORLD UNIVERSITY OF BANGLADESH</span>
                                               <p >I am studying at the World University of Bangladesh in  Computer Science Engineering Department.</p>
                                                
                                            </div>
                                        </div>
                                    </div>
                                    <div class="panel panel-default">
                                        <div class="panel-heading" role="tab" id="headingThree">
                                            <h4 class="panel-title">
                                                <a class="collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseThree" aria-expanded="false" aria-controls="collapseThree">Diploma in Computer Science.
                                                    <span class="pull-right"><i class="fa fa-plus-circle"></i></span>
                                                </a>
                                            </h4>
                                        </div>
                                        <div id="collapseThree" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree">
                                            <div class="panel-body">
                                                  <span class="heading-meta" style="font-size: 13px;">Munshiganj Polytechnic Institut</span>

                                                <p>I completed Diploma in Computer Science from Munshiganj Polytechnic Institute(Gov.) in 2019.I got 3.7 cGPA.</p>  
                                            </div>
                                        </div>
                                    </div>
                                        <div class="panel panel-default">
                                        <div class="panel-heading" role="tab" id="headingFive">
                                            <h4 class="panel-title">
                                                <a class="collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseFive" aria-expanded="false" aria-controls="collapseFive">Cyber Awareness Goverment Certificate.
                                                    <span class="pull-right"><i class="fa fa-plus-circle"></i></span>
                                                </a>
                                            </h4>
                                        </div>
                                        <div id="collapseFive" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingFive">
                                            <div class="panel-body">
                                                 <span class="heading-meta" style="font-size: 13px;">E-Awareness Olympiad Certificate Of Participation.
                                                 </span>
                                               
                                                 <li style="padding: 20px; background-color:#2c98f0;display: inline-block;"><a href="<?php echo e(URL::to('public/mycircificat/adnan.pdf')); ?>" style="color: #fff;">Viwe this Certificate </a></li>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="panel panel-default">
                                        <div class="panel-heading" role="tab" id="headingFour">
                                            <h4 class="panel-title">
                                                <a class="collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseFour" aria-expanded="false" aria-controls="collapseFour">Web Design And Web Application development with Advance Laravel Certificate.
                                                    <span class="pull-right"><i class="fa fa-plus-circle"></i></span>
                                                </a>
                                            </h4>
                                        </div>
                                        <div id="collapseFour" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingFour">
                                            <div class="panel-body">
                                                  <span class="heading-meta" style="font-size: 13px;">R.R.F,BELANCER,&ADN EDU.SERVICES LTD.</span>
                                                <p>I was completed the web design in 2015 from the <b>R.R Foundation</b>.After that i was completed Web and Application Development from <b>Belancer
                                                </b> .. After all i completed Advance Laravel from <b>ADN EDU.SERVICES</b>
                                                <div class="Certification"><li><a href="<?php echo e(URL::to('public/mycircificat/Certificate_G042483_Al Adnan Mehedi.pdf')); ?>">Viwe Certification by Govt.</a></li>
                                                <li><a href="<?php echo e(URL::to('public/mycircificat/adnan.webp')); ?>">Viwe Certification by ADN.</a></li></div>


                                            </div>
                                        </div>
                                    </div>




                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <?php
            $all_expr=DB::table('experiences')->orderBy('id', 'desc')
            ->limit(1)
           ->get();

            ?>
            <?php $__currentLoopData = $all_expr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <section class="colorlib-experience" data-section="experience">
                <div class="colorlib-narrow-content">
                    <div class="row">
                        <div class="col-md-6 col-md-offset-3 col-md-pull-3 animate-box" data-animate-effect="fadeInLeft">
                            <span class="heading-meta">Experience</span>
                            <h2 class="colorlib-heading animate-box">Work Experience</h2>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                         <div class="timeline-centered">
                             <article class="timeline-entry animate-box" data-animate-effect="fadeInLeft">
                                <div class="timeline-entry-inner">

                                   <div class="timeline-icon color-1">
                                      <i class="fa fa-pencil fa-lg"></i>
                                   </div>

                                   <div class="timeline-label" style="background-color: /* Permalink - use to edit and share this gradient: https://colorzilla.com/gradient-editor/#87e0fd+0,c7d6db+49,d0dadd+68,dbdbdb+69,dbdbdb+69,9dcedd+84,05abe0+100&0.34+1,1+100 */
background: -moz-linear-gradient(45deg,  rgba(135,224,253,0.34) 0%, rgba(136,224,252,0.34) 1%, rgba(199,214,219,0.66) 49%, rgba(208,218,221,0.79) 68%, rgba(219,219,219,0.8) 69%, rgba(157,206,221,0.9) 84%, rgba(5,171,224,1) 100%); /* FF3.6-15 */
background: -webkit-gradient(linear, left bottom, right top, color-stop(0%,rgba(135,224,253,0.34)), color-stop(1%,rgba(136,224,252,0.34)), color-stop(49%,rgba(199,214,219,0.66)), color-stop(68%,rgba(208,218,221,0.79)), color-stop(69%,rgba(219,219,219,0.8)), color-stop(84%,rgba(157,206,221,0.9)), color-stop(100%,rgba(5,171,224,1))); /* Chrome4-9,Safari4-5 */
background: -webkit-linear-gradient(45deg,  rgba(135,224,253,0.34) 0%,rgba(136,224,252,0.34) 1%,rgba(199,214,219,0.66) 49%,rgba(208,218,221,0.79) 68%,rgba(219,219,219,0.8) 69%,rgba(157,206,221,0.9) 84%,rgba(5,171,224,1) 100%); /* Chrome10-25,Safari5.1-6 */
background: -o-linear-gradient(45deg,  rgba(135,224,253,0.34) 0%,rgba(136,224,252,0.34) 1%,rgba(199,214,219,0.66) 49%,rgba(208,218,221,0.79) 68%,rgba(219,219,219,0.8) 69%,rgba(157,206,221,0.9) 84%,rgba(5,171,224,1) 100%); /* Opera 11.10-11.50 */
background: -ms-linear-gradient(45deg,  rgba(135,224,253,0.34) 0%,rgba(136,224,252,0.34) 1%,rgba(199,214,219,0.66) 49%,rgba(208,218,221,0.79) 68%,rgba(219,219,219,0.8) 69%,rgba(157,206,221,0.9) 84%,rgba(5,171,224,1) 100%); /* IE10 preview */
background: linear-gradient(45deg,  rgba(135,224,253,0.34) 0%,rgba(136,224,252,0.34) 1%,rgba(199,214,219,0.66) 49%,rgba(208,218,221,0.79) 68%,rgba(219,219,219,0.8) 69%,rgba(157,206,221,0.9) 84%,rgba(5,171,224,1) 100%); /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#5787e0fd', endColorstr='#05abe0',GradientType=1 ); /* IE6-9 fallback on horizontal gradient */
">
                                      <h2><a href="#">Full Stack Developer</a> <span>2014-2020</span></h2>
                                      <p><?php echo e($exp->full_developer); ?> <!-- I am happy to know you
                                     that 250+ projects done sucessfully! All were development projects.My customers are happy with my work.Because I am very sincerely accomplishing my tasks. --></p>
                                   </div>
                                </div>
                             </article>


                             <article class="timeline-entry animate-box" data-animate-effect="fadeInRight">
                                <div class="timeline-entry-inner">
                                   <div class="timeline-icon color-2">
                                      <i class="fa fa-pencil fa-lg"></i>
                                   </div>
                                   <div class="timeline-label" style="background-color: /* Permalink - use to edit and share this gradient: https://colorzilla.com/gradient-editor/#f3c5bd+0,e86c57+56,e86c57+56,e85f47+66,ffa468+81,c72200+100&0.4+0,1+100 */
background: -moz-linear-gradient(45deg,  rgba(243,197,189,0.4) 0%, rgba(232,108,87,0.74) 56%, rgba(232,95,71,0.8) 66%, rgba(255,164,104,0.89) 81%, rgba(199,34,0,1) 100%); /* FF3.6-15 */
background: -webkit-gradient(linear, left bottom, right top, color-stop(0%,rgba(243,197,189,0.4)), color-stop(56%,rgba(232,108,87,0.74)), color-stop(66%,rgba(232,95,71,0.8)), color-stop(81%,rgba(255,164,104,0.89)), color-stop(100%,rgba(199,34,0,1))); /* Chrome4-9,Safari4-5 */
background: -webkit-linear-gradient(45deg,  rgba(243,197,189,0.4) 0%,rgba(232,108,87,0.74) 56%,rgba(232,95,71,0.8) 66%,rgba(255,164,104,0.89) 81%,rgba(199,34,0,1) 100%); /* Chrome10-25,Safari5.1-6 */
background: -o-linear-gradient(45deg,  rgba(243,197,189,0.4) 0%,rgba(232,108,87,0.74) 56%,rgba(232,95,71,0.8) 66%,rgba(255,164,104,0.89) 81%,rgba(199,34,0,1) 100%); /* Opera 11.10-11.50 */
background: -ms-linear-gradient(45deg,  rgba(243,197,189,0.4) 0%,rgba(232,108,87,0.74) 56%,rgba(232,95,71,0.8) 66%,rgba(255,164,104,0.89) 81%,rgba(199,34,0,1) 100%); /* IE10 preview */
background: linear-gradient(45deg,  rgba(243,197,189,0.4) 0%,rgba(232,108,87,0.74) 56%,rgba(232,95,71,0.8) 66%,rgba(255,164,104,0.89) 81%,rgba(199,34,0,1) 100%); /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#66f3c5bd', endColorstr='#c72200',GradientType=1 ); /* IE6-9 fallback on horizontal gradient */
">
                                    <h2><a href="#">Front End Developer</a> <span>2014-2020</span></h2>
                                      <p><?php echo e($exp->front_end); ?><!-- I do web development as well as responsive web design.And front End development. with <b>VUE.Js </b>It makes my web page run faster. --></p>
                                   </div>
                                </div>
                             </article>

                             <article class="timeline-entry animate-box" data-animate-effect="fadeInLeft">
                                <div class="timeline-entry-inner">
                                   <div class="timeline-icon color-3">
                                      <i class="fa fa-pencil fa-lg"></i>
                                   </div>
                                   <div class="timeline-label" style="background-color: /* Permalink - use to edit and share this gradient: https://colorzilla.com/gradient-editor/#fceabb+0,fccd4d+78,fccd4d+78,f8b500+80,f9edcc+94,fbdf93+100&0.4+0,1+100 */
background: -moz-linear-gradient(45deg,  rgba(252,234,187,0.4) 0%, rgba(252,205,77,0.87) 78%, rgba(248,181,0,0.88) 80%, rgba(249,237,204,0.96) 94%, rgba(251,223,147,1) 100%); /* FF3.6-15 */
background: -webkit-gradient(linear, left bottom, right top, color-stop(0%,rgba(252,234,187,0.4)), color-stop(78%,rgba(252,205,77,0.87)), color-stop(80%,rgba(248,181,0,0.88)), color-stop(94%,rgba(249,237,204,0.96)), color-stop(100%,rgba(251,223,147,1))); /* Chrome4-9,Safari4-5 */
background: -webkit-linear-gradient(45deg,  rgba(252,234,187,0.4) 0%,rgba(252,205,77,0.87) 78%,rgba(248,181,0,0.88) 80%,rgba(249,237,204,0.96) 94%,rgba(251,223,147,1) 100%); /* Chrome10-25,Safari5.1-6 */
background: -o-linear-gradient(45deg,  rgba(252,234,187,0.4) 0%,rgba(252,205,77,0.87) 78%,rgba(248,181,0,0.88) 80%,rgba(249,237,204,0.96) 94%,rgba(251,223,147,1) 100%); /* Opera 11.10-11.50 */
background: -ms-linear-gradient(45deg,  rgba(252,234,187,0.4) 0%,rgba(252,205,77,0.87) 78%,rgba(248,181,0,0.88) 80%,rgba(249,237,204,0.96) 94%,rgba(251,223,147,1) 100%); /* IE10 preview */
background: linear-gradient(45deg,  rgba(252,234,187,0.4) 0%,rgba(252,205,77,0.87) 78%,rgba(248,181,0,0.88) 80%,rgba(249,237,204,0.96) 94%,rgba(251,223,147,1) 100%); /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#66fceabb', endColorstr='#fbdf93',GradientType=1 ); /* IE6-9 fallback on horizontal gradient */
">
                                    <h2><a href="#"> Laravel Fermwork</a> <span>2017-2020</span></h2>
                                      <p><?php echo e($exp->laravel); ?><!-- Laravel is very popular in the web development context.And Its extremely powerful ,safe and fast.So that, i try to develope all my projects with the laravel framwork.I completed about 100 of the top websites with laravel --></p>
                                   </div>
                                </div>
                             </article>

                             <article class="timeline-entry animate-box" data-animate-effect="fadeInTop">
                                <div class="timeline-entry-inner">
                                   <div class="timeline-icon color-4">
                                      <i class="fa fa-pencil fa-lg"></i>
                                   </div>
                                   <div class="timeline-label" style="background-color: /* Permalink - use to edit and share this gradient: https://colorzilla.com/gradient-editor/#cb60b3+0,c146a1+57,a80077+67,c146a1+75,c146a1+75,a80077+77,db36a4+100&0.3+0,0.7+100 */
background: -moz-linear-gradient(45deg,  rgba(203,96,179,0.3) 0%, rgba(193,70,161,0.53) 57%, rgba(168,0,119,0.57) 67%, rgba(193,70,161,0.6) 75%, rgba(168,0,119,0.61) 77%, rgba(219,54,164,0.7) 100%); /* FF3.6-15 */
background: -webkit-gradient(linear, left bottom, right top, color-stop(0%,rgba(203,96,179,0.3)), color-stop(57%,rgba(193,70,161,0.53)), color-stop(67%,rgba(168,0,119,0.57)), color-stop(75%,rgba(193,70,161,0.6)), color-stop(77%,rgba(168,0,119,0.61)), color-stop(100%,rgba(219,54,164,0.7))); /* Chrome4-9,Safari4-5 */
background: -webkit-linear-gradient(45deg,  rgba(203,96,179,0.3) 0%,rgba(193,70,161,0.53) 57%,rgba(168,0,119,0.57) 67%,rgba(193,70,161,0.6) 75%,rgba(168,0,119,0.61) 77%,rgba(219,54,164,0.7) 100%); /* Chrome10-25,Safari5.1-6 */
background: -o-linear-gradient(45deg,  rgba(203,96,179,0.3) 0%,rgba(193,70,161,0.53) 57%,rgba(168,0,119,0.57) 67%,rgba(193,70,161,0.6) 75%,rgba(168,0,119,0.61) 77%,rgba(219,54,164,0.7) 100%); /* Opera 11.10-11.50 */
background: -ms-linear-gradient(45deg,  rgba(203,96,179,0.3) 0%,rgba(193,70,161,0.53) 57%,rgba(168,0,119,0.57) 67%,rgba(193,70,161,0.6) 75%,rgba(168,0,119,0.61) 77%,rgba(219,54,164,0.7) 100%); /* IE10 preview */
background: linear-gradient(45deg,  rgba(203,96,179,0.3) 0%,rgba(193,70,161,0.53) 57%,rgba(168,0,119,0.57) 67%,rgba(193,70,161,0.6) 75%,rgba(168,0,119,0.61) 77%,rgba(219,54,164,0.7) 100%); /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#4dcb60b3', endColorstr='#b3db36a4',GradientType=1 ); /* IE6-9 fallback on horizontal gradient */
">
                                    <h2><a href="#">Web Application Development</a> <span>2017-2020</span></h2>
                                      <p><?php echo e($exp->web_application); ?><!-- Sometimes customers need to create web applications as needed. For example That could be the point of sale system(POS) --></p>
                                   </div>
                                </div>
                             </article>

                           

                             <article class="timeline-entry begin animate-box" data-animate-effect="fadeInBottom">
                                <div class="timeline-entry-inner">
                                   <div class="timeline-icon color-none">
                                   </div>
                                </div>
                             </article>
                          </div>
                       </div>
                   </div>
                </div>
            </section>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <section class="colorlib-work" data-section="work">
                <div class="colorlib-narrow-content">
                    <div class="row">

                        <div class="col-md-6 col-md-offset-3 col-md-pull-3 animate-box" data-animate-effect="fadeInLeft">
                            <span class="heading-meta">My Work</span>
                            <h2 class="colorlib-heading animate-box">Recent Work</h2>
                        </div>
                    </div>
                    <div class="row">
                        
                
                            <ul id="filter-list" class="clearfix controls">

                      <button class="filter waves-effect waves-light btn animate-box" style="background-color:#16A1E7;" data-filter="all">All</button>
                      <button class="filter waves-effect waves-light btn animate-box" style="background-color:#16A1E7;" data-filter=".webdesign">Web Design</button>
                    
                      
                      <button class="filter waves-effect waves-light btn animate-box" style="background-color:#16A1E7;" data-filter=".illustration waves-effect waves-light btn">Cyber War</button>
                     
                      <button class="filter waves-effect waves-light btn animate-box" style="background-color:#16A1E7;" data-filter=".photoshop">Cyber security</button>
                    </ul><!-- @end  #filter-list -->     <div class="col-md-6 col-md-offset-3 col-md-pull-3 animate-box" data-animate-effect="fadeInLeft">
                            
                        </div>
                              <ul id="portfolio">
                            <div class="col-md-4 animate-box">
                              <li class="mix logo photoshop">
                                <a href="#"><img src="https://drive.google.com/uc?id=1hacwhEPKAqRlNF3zWTR2eQAES4TC56ko" type="image/jpg" alt="three" border="0" class="lazyloaded" loading="lazy"></a>
                                </a>
                            </li>

                            </div>
                            <div class="col-md-4 animate-box">
                              <li class="mix logo photoshop illustration">
                               <a href="#"><img src="https://drive.google.com/uc?id=1vq8iYMD6y4xcIO2OKIeyjsKuGPLjSfSW" type="image/jpg" alt="one" border="0" class="lazyloaded" loading="lazy"></a>
                            </li>
                            </div>
                            <div class="col-md-4 animate-box">
                              <li class="mix photoshop illustration">
                                <a href="#"><img src="https://drive.google.com/uc?id=16vuTpTqBnEs_5oVlyVjbh_6-vtQLHJou" type="image/jpg" alt="two" border="0" class="lazyloaded" loading="lazy"></a>
                            </li>
                            </div>
                            
                        
                            <div class="col-md-4 animate-box">
                             <li class="mix animation webdesign">
                            <a href="#"><img src="https://drive.google.com/uc?id=1CVLTt68A4HnA5IXh9v_8E7yRYz8CVN0g" type="image/jpg" alt="a2" border="0" class="lazyloaded" loading="lazy" ></a></li>
                          </div>
                          <div class="col-md-4 animate-box">
                             <li class="mix animation webdesign">
                            <a href="#"><img src="https://drive.google.com/uc?id=143t6qgydGU3Ng_uQK0gSHdGcZ8jowkK0" type="image/jpg" alt="a1" border="0" class="lazyloaded" loading="lazy"></a></li>
                          </div>
                            <div class="col-md-4 animate-box">
                             <li class="mix animation webdesign">
                            <a href="#"><img src="https://drive.google.com/uc?id=1Ka3IWNzWq_KeJ66VWHMTc2yKoHX9uUvL" type="image/jpg" alt="a" border="0" class="lazyloaded" loading="lazy"></a></li>
                          </div>
                         
                         
                            </ul>
                            <!-- @end  #portfolio -->
                            </div>
                            <!-- @end  #w -->
            
                </div>
            </section>

            <section class="colorlib-blog" data-section="blog" style="cursor:not-allowed;">
                <div class="colorlib-narrow-content">
                    <div class="row">
                        <div class="col-md-6 col-md-offset-3 col-md-pull-3 animate-box" data-animate-effect="fadeInLeft">
                            <span class="heading-meta">Read</span>
                            <h2 class="colorlib-heading">Recent Blog Coming Soon..</h2>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4 col-sm-6 animate-box" data-animate-effect="fadeInLeft">
                            <div class="blog-entry">
                                <a href="#" class="blog-img"><img src="https://drive.google.com/uc?id=1H1TrEtyRuAOdfAC11iI-bt8vkU2Yhu_i" type="image/jpg"  alt="blg" border="0" class="lazyloaded" loading="lazy"></a>
                                <div class="desc">
                                    <span><small>April 14, 2020 </small> | <small> Hacking </small> | <small> <i class="icon-bubble3"></i> 4</small></span>
                                    <h3><a href="#" style="cursor: not-allowed;">Kali Linux with Cyber Security</a></h3>
                                    
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-6 animate-box" data-animate-effect="fadeInRight">
                            <div class="blog-entry">
                                <a href="#" class="blog-img"><img src="https://i.ibb.co/XD72zRQ/laravel.png" type="image/png" alt="laravel" border="0" class="lazyloaded" loading="lazy"></a>
                                <div class="desc">
                                    <span><small>April 14, 2020 </small> | <small> Web Development </small> | <small> <i class="icon-bubble3"></i> 4</small></span>
                                    <h3><a href="#"  style="cursor: not-allowed;">Laravel for a Beginner</a></h3>
                                    
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-6 animate-box" data-animate-effect="fadeInLeft">
                            <div class="blog-entry">
                                <a href="#" class="blog-img"><img src="https://i.ibb.co/NxKk0RJ/li.png" type="image/png" alt="li" border="0" class="lazyloaded" loading="lazy"></a>
                                <div class="desc">
                                    <span><small>April 14, 2020 </small> | <small> Inspiration </small> | <small> <i class="icon-bubble3"></i> 4</small></span>
                                    <h3><a href="#"  style="cursor: not-allowed;">Make website from scratch</a></h3>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12 animate-box">
                            <p><a href="#" class="btn btn-primary btn-lg btn-load-more">Load more <i class="icon-reload"></i></a></p>
                        </div>
                    </div>
                </div>
            </section>
            <div id="con">
            <section class="colorlib-contact" data-section="contact">
                <div class="colorlib-narrow-content">
                    <div class="row">
                        <div class="col-md-6 col-md-offset-3 col-md-pull-3 animate-box" data-animate-effect="fadeInLeft">
                            <span class="heading-meta">Get in Touch</span>
                            <h2 class="colorlib-heading">Contact</h2>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-5">
                            <div class="colorlib-feature colorlib-feature-sm animate-box" data-animate-effect="fadeInLeft">
                                <div class="colorlib-icon">
                                    <i class="fa fa-envelope"></i>
                                </div>
                                <div class="colorlib-text">
                                    <p><a href="mailto:adnanjohan54@gmail.com">adnanjohan54@gmail.com</a></p>
                                </div>
                            </div>

                            <div class="colorlib-feature colorlib-feature-sm animate-box" data-animate-effect="fadeInLeft">
                                <div class="colorlib-icon">
                                    <i class="fa fa-map-marker"></i>
                                </div>
                                <div class="colorlib-text">
                                    <p>Dhaka,Bangladesh.</p>
                                </div>
                            </div>

                            <div class="colorlib-feature colorlib-feature-sm animate-box" data-animate-effect="fadeInLeft">
                                <div class="colorlib-icon">
                                    <i class="fa fa-phone"></i>
                                </div>
                                <div class="colorlib-text">
                                    <a href="tel:+8801937383435" style="">+8801937383435</a>
                                </div>
                            </div>
                            <div class="colorlib-text">
                                    <a href="#" style="color: #fff">hi</a>
                                </div>

                        </div>
                        <div class="col-md-7 col-md-push-1">
                            <div class="row">
                                <div class="col-md-10 col-md-offset-1 col-md-pull-1 animate-box" data-animate-effect="fadeInRight">
                                    <form action="<?php echo e(url('/send_massage')); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <div class="form-group">
                                            <input type="text" name="name" class="form-control" placeholder="Name" required>
                                        </div>
                                        <div class="form-group">
                                            <input type="email" name="email" class="form-control" placeholder="Email" required>
                                        </div>
                                        <div class="form-group">
                                            <input type="text" name="subject" class="form-control" placeholder="Subject" required>
                                        </div>
                                        <div class="form-group">
                                            <textarea name="massage" id="message" cols="30" rows="7" class="form-control" placeholder="Message" required></textarea>
                                        </div>
                                        <div class="form-group">
                                            <input type="submit" class="btn btn-primary btn-send-message" value="Send Message">
                                        </div>
                                    </form>
                                </div>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>

        </div><!-- end:colorlib-main -->
    </div><!-- end:container-wrap -->
    </div><!-- end:colorlib-page -->

    <!-- jQuery -->
    <script src="<?php echo e(asset('public/home/js/mix.js')); ?>" async></script>

    <script src="<?php echo e(asset('public/home/js/jquery.min.js')); ?>" async></script>
    <!-- jQuery Easing -->
    <script src="<?php echo e(asset('public/home/js/jquery.easing.1.3.js')); ?>" async></script>
    <!-- Bootstrap -->
    <script src="<?php echo e(asset('public/home/js/bootstrap.min.js')); ?>" async></script>
    <!-- Waypoints -->
    <script src="<?php echo e(asset('public/home/js/jquery.waypoints.min.js')); ?>" async></script>
    <!-- Flexslider -->
    <script src="<?php echo e(asset('public/home/js/jquery.flexslider-min.js')); ?>" async></script>
    <!-- Owl carousel -->
    <script src="<?php echo e(asset('public/home/js/owl.carousel.min.js')); ?>" async></script>
    <!-- Counters -->
    <script src="<?php echo e(asset('public/home/js/jquery.countTo.js')); ?>" async></script>
    
    
    <!-- MAIN JS -->
    <script src="<?php echo e(asset('public/home/js/main.js')); ?>" async></script>
    <!-- protfollio -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.0.1/js/toastr.js"></script>


<script src="https://cdn.jsdelivr.net/jquery.mixitup/latest/jquery.mixitup.min.js" async></script>
<script src="https://mixitup.kunkalabs.com/wp-content/themes/mixitup.kunkalabs/js/main.min.js?ver=1.3.1" async></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.97.5/js/materialize.min.js" async></script>
<script src="lazysizes.min.js" async></script>




   <script>
      <?php if(Session::has('messege')): ?>
        var type="<?php echo e(Session::get('alert-type','info')); ?>"
        switch(type){
            case 'info':
                 toastr.info("<?php echo e(Session::get('messege')); ?>");
                 break;
            case 'success':
                toastr.success("<?php echo e(Session::get('messege')); ?>");
                break;
            case 'warning':
                toastr.warning("<?php echo e(Session::get('messege')); ?>");
                break;
            case 'error':
                toastr.error("<?php echo e(Session::get('messege')); ?>");
                break;
        }
      <?php endif; ?>
    </script>

    </body>
</html>

