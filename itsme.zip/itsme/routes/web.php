  <?php 

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('home');
});

Auth::routes();

Route::get('/backend', 'HomeController@index')->name('backend');
Route::get('/backend', 'HomeController@sub')->name('backend');

// info images area hare////////////////////////////////////////
Route::get('/add_infoimage', 'infoimagecontroller@infoimage')->name('add_infoimage');
Route::post('/insert_infoimage', 'infoimagecontroller@insert_infoimage');
Route::get('/all_infoimages', 'infoimagecontroller@all_infoimages')->name('all_infoimages');
Route::get('/edit_photo/{id}', 'infoimagecontroller@edit_photo')->name('edit_photo');
Route::post('/update_info/{id}', 'infoimagecontroller@update_info');
Route::get('/delete_image/{id}', 'infoimagecontroller@delete_image')->name('delete_image');
// slider route is Here//////////////////////////////////////////////////////////////
Route::get('/add_slider', 'slidercontroller@add_slider')->name('add_slider');
Route::get('/all_slider', 'slidercontroller@all_slider')->name('all_slider');
Route::post('/insert_slider', 'slidercontroller@insert_slider');

Route::get('/edit_slider/{id}', 'slidercontroller@edit_slider')->name('edit_slider');
Route::post('/update_slider/{id}', 'slidercontroller@update_slider');
Route::get('/delete_slider/{id}', 'slidercontroller@delete_slider')->name('delete_slider');

// second slider///////////////////////////////////////////////////////////////////
Route::get('/add_second_slider', 'secondslidercontroller@add_second_slider')->name('add_second_slider');
Route::get('/all_second_slider', 'secondslidercontroller@all_second_slider')->name('all_second_slider');
Route::post('/insert_second_slider', 'secondslidercontroller@insert_second_slider');

Route::get('/edit_second_slider/{id}', 'secondslidercontroller@edit_second_slider')->name('edit_second_slider');
Route::post('/update_second_slider/{id}', 'secondslidercontroller@update_second_slider');
Route::get('/delete_second_slider/{id}', 'secondslidercontroller@delete_second_slider')->name('delete_second_slider');
 // cv area is hera///////////////////////////////////////////////
Route::get('/add_cv', 'cvcontroller@add_cv')->name('add_cv');
Route::post('/insert_cv', 'cvcontroller@insert_cv');
Route::get('/all_cv', 'cvcontroller@all_cv')->name('all_cv');
Route::get('/delete_cv/{id}', 'cvcontroller@delete_cv')->name('delete_cv');
// Expert area is hare/////////////////////////////////////////////////////////////
Route::get('/add_expert', 'skillcontroller@index')->name('add_expert');
Route::post('/insert_expert', 'skillcontroller@insert_expert');
Route::get('/all_expert', 'skillcontroller@all_expert')->name('all_expert');
Route::get('/delete_expert/{id}', 'skillcontroller@delete_expert')->name('delete_expert');
Route::get('/edit_expert/{id}', 'skillcontroller@edit_expert')->name('edit_expert');
Route::post('/update_expert/{id}', 'skillcontroller@update_expert');
// massage/////////////////////////////////////////////////////////////
Route::post('/send_massage', 'massagecontroller@send_massage');
Route::get('/all_massage', 'skillcontroller@all_massage')->name('all_massage');
Route::get('/delete_massage/{id}', 'skillcontroller@delete_massage')->name('delete_massage');
// experience area/////////////////////////////////////////
Route::get('/add_exp', 'experiencecontroller@index')->name('add_exp');
Route::post('/insert_exp', 'experiencecontroller@insert_exp');
Route::get('/all_exp', 'experiencecontroller@all_exp')->name('all_exp');
Route::get('/edit_exp/{id}', 'experiencecontroller@edit_exp')->name('edit_exp');
Route::post('/update_exp/{id}', 'experiencecontroller@update_exp');
Route::get('/delete_exp/{id}', 'experiencecontroller@delete_exp')->name('delete_exp');

